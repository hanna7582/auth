<template>
    <article class="check-browser">
            아직... 크롬에서만 정상적으로 지원합니다.
    </article>
</template>

<style lang="scss" scoped>
    .check-browser{
        width: 100vw;
        height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        color: $White;
        font-size: 16px;
    }
</style>
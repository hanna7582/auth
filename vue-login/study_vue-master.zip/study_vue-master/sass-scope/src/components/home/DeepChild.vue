<template>
    <div class="deep-child">
        <p>홈 - 자식 컴포넌트</p>
        <div class="deep-child-container">
            자아아아식
        </div>
    </div>
</template>

<script>
export default {
    name: 'DeepChild',
}
</script>



class User {
    constructor(user_id, user_pwd, user_role){
        this.user_id = user_id;
        this.user_pwd = user_pwd;
        this.user_role = user_role;
    }
}
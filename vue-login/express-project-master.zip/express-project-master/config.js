exports.SQL = {
    host: '192.168.99.100',
    user: 'root',
    port: 3306,
    password: 'password',
    database: 'testDB'
}


exports.KEY = {
    'secret': 'Dinner'
}
